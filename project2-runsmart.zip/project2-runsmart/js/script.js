// Modal
alert();
$('[data-modal=consultation]').on('click', function() {
    $('.notvisible, #consultation').fadeIn('slow'); //fadeIn = появление окошки с задержкой
});
$('.modal__close').on('click', function() {
    $('.notvisible, #consultation, #thanks, #order').fadeOut('slow'); //fadeOut = закрытие
});

$('.button_mini').each(function(i) {
    $(this).on('click', function() {
        $('#order .modaldescr').text($('.catalog-itemsubtitle').eq(i).text());
        $('.notvisible, #order').fadeIn('slow');
    })
});

//more_info

// $('#more_link').on('click', function()) {
//     $()
// }

//----------------


//