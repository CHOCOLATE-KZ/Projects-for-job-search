$('ul.catalog_tabs').on('click', 'li:not(.catalog_tab_active)', function() {
    $(this)
        .addClass('catalog_tab_active').siblings().removeClass('catalog_tab_active')
        //siblings = фильтравация, убирает active
        .closest('div.container2').find('div.catalog_content').removeClass('catalog_content_active').eq($(this).index()).addClass('catalog_content_active');

});

function ilyasik(item) {
    //each = нужен для циклических операций
    $(item).each(function(i) {
        //onclick = при нажатий
        $(this).on('click', function(e) {
            e.preventDefault(); //отменяет действие браузера по умолчанию
            $('.catalog_item_content').eq(i).toggleClass('catalog_item_content_active'); // eq(i) = индекс элемента начинается с 0
            $('.catalog_item_list').eq(i).toggleClass('catalog_item_list_active');
            //toggleClass = Переключатель классов. Добавляет элементу указанный класс, если его нет. Иначе удаляет.
        });
    });
}
ilyasik('.catalog_item_link');
ilyasik('.catalog_item_back');