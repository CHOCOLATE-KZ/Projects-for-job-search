const outputWords = [
    'makes you happy',
    'is produced',
    'works',
]
const typeout = document.querySelector('#typeout')
let wordIndex = 0
let charIndex = 0


printWord()

function printWord() {
    if (outputWords[wordIndex].length > charIndex) { //печатает до последнии буквы имени
        typeout.innerHTML += outputWords[wordIndex].charAt(charIndex)
        charIndex += 1
            //буквы печатаются со скоростью 2.3 ms

        setTimeout(printWord, 230)
    } else {
        setTimeout(deleteWord, 50)
    }
}

//Фун-ия для удаления слова
function deleteWord() {
    if (charIndex >= 0) {
        typeout.innerHTML = outputWords[wordIndex].substr(0, charIndex)
        charIndex -= 1
        setTimeout(deleteWord, 150)
    } else {
        wordIndex += 1
        if (wordIndex >= outputWords.length) {
            wordIndex = 0
        }

        setTimeout(printWord, 150)
    }
}